var express = require("express");
var app = express ();

app.use((req, res, next) => {
    console.log('Time:' , Date.now());
    next();
})

app.get("/myapps/helloworld", function(req, res) {
    res.send ("Hello World");
});

app.listen(8888, function(){
    console.log("Application started and listening on port 8888.");
});