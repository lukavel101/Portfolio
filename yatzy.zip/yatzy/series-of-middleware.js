var express = require("express");
var app = express ();


app.use('/user/:id', (req, res, next) =>{
    console.log('Request URL: ', req.originalUrl);
    if (req.params == '99'){
        res.send("I am user 99.")
    }
    next()
}, (req, res,  next) =>{
    console.log('Request Type: ', req.method);
    next();
});
app.listen(9999, function(){
    console.log("Application started and listening on port 9999.");
});