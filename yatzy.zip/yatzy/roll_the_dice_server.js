const express = require("express");
const app = express();

const PORT = 8888;

app.use(express.static('public')); //Serve the static files form 'public' directory
app.use(express.json());

app.get('/services/roll-dice', (req, res) =>{
    let randomDice=[];
    for (let i=0;i<5;i++) {
      randomDice.push(Math.floor(Math.random()*6)+1);
    }
    res.json(randomDice);
});
app.post('/services/calculateUpperSection', (req, res) => {
    
    let upperSection = req.body;
    const sumUpperSection = upperSection.reduce(
    (accumulator, currentValue) => parseInt(accumulator) + parseInt(currentValue)
    );
    res.send({sumUpperSection});
    console.log(req.body);
    console.log(sumUpperSection);

    res.end();

});
app.listen(PORT, ()=>{
    console.log(`Server is running on http://localhost:${PORT}`);
})